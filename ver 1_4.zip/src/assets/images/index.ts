import sarttHeader from './SARTT_Header.gif';
import sarttLogueo from './SARTT_Logueo.gif';
import truperIcon from './trupicon.png';
import logoHeader from './logo_header.png';

export const images = {
  sarttHeader,
  sarttLogueo,
  truperIcon,
  logoHeader,
};
