// src/components/common/Pagination.messages.ts
export const paginationText = {
  previous: 'Anterior',
  next: 'Siguiente',
  // Nota: Si más adelante quieres centralizar también esta etiqueta,
  // añade aquí: rowsPerPageLabel: 'Filas por página:'
};
