export { default } from '@/pages/iniciales/responsiveAppBar';

