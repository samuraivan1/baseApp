export const footerMessages = {
  copyright: 'SART © 2025',
  lastUpdate: 'Septiembre 2025',
};

