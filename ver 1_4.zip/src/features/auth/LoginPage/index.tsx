export { default } from '@/pages/LoginPage';

