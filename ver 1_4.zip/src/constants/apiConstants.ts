export const STATUS_CODE_NOT_FOUND = 404;
export const STATUS_CODE_CONFLICT = 409;
export const STATUS_CODE_OK = 200;
export const STATUS_CODE_CREATED = 201;
