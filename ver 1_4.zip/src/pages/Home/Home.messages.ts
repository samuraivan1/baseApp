export const homeMessages = {
  welcome: 'Bienvenido,',
  defaultUser: 'Usuario',
  tagline: 'Gestiona tus proyectos y tareas de forma eficiente.',
  button: 'Ir a mi Tablero Kanban',
};