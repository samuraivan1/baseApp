export const seguridadMessages = {
  title: 'Seguridad',
  usuarios: 'Usuarios',
  roles: 'Roles',
  permisos: 'Permisos',
};

