export const userFormMessages = {
  name: 'Nombre',
  email: 'Correo electrónico',
  createSuccess: 'Usuario creado con éxito',
  updateSuccess: 'Usuario actualizado con éxito',
  genericError: 'Ocurrió un error al guardar el usuario',
};

