// src/pages/Kanban/components/Task/Task.messages.ts
export const taskMessages = {
  days: 'días',
};
