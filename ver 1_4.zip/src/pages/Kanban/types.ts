import { TareaType as ApiTareaType } from '@/services/api.types';
export type TaskType = ApiTareaType;
