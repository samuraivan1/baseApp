import React from 'react';

const Project: React.FC = () => {
  return <div>Hola Project</div>;
};

export default Project;
