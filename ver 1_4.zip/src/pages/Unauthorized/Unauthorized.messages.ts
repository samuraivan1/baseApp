// src/pages/Unauthorized/Unauthorized.messages.ts
export const unauthorizedText = {
  title: 'Acceso no autorizado',
  description: 'No tienes permisos para ver esta página.',
  backHome: 'Ir a inicio',
};
