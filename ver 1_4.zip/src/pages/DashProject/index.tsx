import React from 'react';

const DashProject: React.FC = () => {
  return <div>Hola DashProject</div>;
};

export default DashProject;
